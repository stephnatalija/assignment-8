/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package csi2300assignment8;


/**
 *
 * @author sstan
 */
public class CSI2300Assignment8 {
    // index = i
    public static int fibonacci(int i) {
        if (i <= 1){ 
            return i; // returns i if i <= 1
        } else { 
            // if i > 1, computes -->
            return fibonacci (i - 1) + fibonacci (i - 2); 
    } // end of else
    } // end of public static int fibonacci
    
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        int i = 10; // up to the tenth term
        int j; // initalize
        for (j = 0; j < i; j++) {
            System.out.print(fibonacci(j) + " "); 
        }
        
    } // end of main
    // main uses fib. to output i up to the tenth term
    
} // end
